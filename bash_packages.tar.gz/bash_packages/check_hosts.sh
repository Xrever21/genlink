#!/bin/bash

# Список хостов для проверки доступности
HOSTS=("192.168.1.1" "google.com" "yahoo.com")

# Счетчики доступных и недоступных хостов
AVAILABLE=0
UNAVAILABLE=0

# Проверка каждого хоста с помощью ping
for HOST in "${HOSTS[@]}"; do
    if ping -c 1 "$HOST" &> /dev/null; then
        echo "Хост $HOST доступен"
        ((AVAILABLE++))
    else
        echo "Хост $HOST недоступен"
        ((UNAVAILABLE++))
    fi
done

# Вывод общего количества доступных и недоступных хостов
echo "Доступных хостов: $AVAILABLE"
echo "Недоступных хостов: $UNAVAILABLE"
